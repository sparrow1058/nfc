/** Automatically generated file. DO NOT MODIFY */
package com.example.m1card;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}